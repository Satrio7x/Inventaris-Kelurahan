<?php
include "config.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Daftar Inventaris Kelurahan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Daftar Inventaris Kelurahan</h1>
        <?php
        $kategori = mysqli_query($conn, "SELECT * FROM kategori");
        while($row = mysqli_fetch_assoc($kategori)) {
            echo "<h2>" . htmlspecialchars($row['nama_kategori']) . "</h2><ul>";
            $items = mysqli_query($conn, "SELECT * FROM inventaris WHERE id_kategori=" . $row['id_kategori']);
            while($item = mysqli_fetch_assoc($items)) {
                echo "<li>" . htmlspecialchars($item['nama_barang']) . "</li>";
            }
            echo "</ul>";
        }
        ?>
    </div>
</body>
</html>
