<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Inventaris Kelurahan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="dashboard-container">
        <h1>Selamat Datang, <?= $_SESSION['username'] ?>!</h1>
        <p>Anda berhasil login.</p>
        <a href="index.php" class="button">Lihat Inventaris</a>
        <a href="logout.php" class="logout-button">Logout</a>
    </div>
</body>
</html>