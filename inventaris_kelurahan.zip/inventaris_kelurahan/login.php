<?php session_start(); if(isset($_SESSION['username'])) { header("Location: dashboard.php"); exit(); } ?>
<!DOCTYPE html>
<html>
<head>
    <title>Login - Inventaris Kelurahan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <h2>Inventaris Kelurahan</h2>
        <form method="POST" action="proses_login.php">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>